---
type: Policy
id: https://w3id.org/ktl/knowledge/policies/code-of-conduct
title: Code of conduct
description: "Contributor Covenant v2.1: its scope over issues, pull requests and discussions, and how to report unacceptable behaviour."
genre: reference
resource: CODE_OF_CONDUCT.md
generated:
  by: process:ktl-librarian
  at: "2026-10-12T16:08:20Z"
status: draft
verified:
- by: process:ktl-librarian
  at: "2026-10-06T11:10:52Z"
---

# Overview

The code of conduct is adapted from the Contributor Covenant, version 2.1. It applies within all project spaces and when someone officially represents the project in public spaces. Enforcement reports go to the maintainer, and are reviewed promptly and fairly.
