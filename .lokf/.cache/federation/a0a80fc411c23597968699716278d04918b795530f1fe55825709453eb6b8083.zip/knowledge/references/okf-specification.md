---
type: Reference
id: https://w3id.org/ktl/knowledge/references/okf-specification
title: OKF specification (v0.2)
description: Google's Open Knowledge Format - a folder of Markdown concept files with YAML frontmatter, requiring only `type`, plus the v0.2 provenance, trust, and lifecycle families.
genre: reference
resource: https://github.com/GoogleCloudPlatform/open-knowledge-format/blob/main/SPEC.md
generated:
  by: human:noelmcloughlin
  at: "2026-10-13T00:51:55Z"
verified:
- by: human:noelmcloughlin
  at: "2026-09-09T16:35:55Z"
- by: human:noelmcloughlin
  at: "2026-09-26T20:42:16Z"
- by: process:ktl-librarian
  at: "2026-10-06T11:10:52Z"
- by: human:noelmcloughlin
  at: "2026-10-13T00:51:55Z"
stale_after: 2027-09-26
---

# Overview

Every LOKF bundle is also a valid OKF bundle. OKF supplies the substrate the
skills depend on: one concept per file with path as concept ID, `type` as the
only strictly required field, and permissive consumption - unknown types,
unknown keys, and broken cross-links must never cause rejection.

Sections 5.1-5.5 define the trust vocabulary this repository's whole thesis
rests on: `sources` (provenance) and `generated`, `verified` (trust events),
`status` and `stale_after` (lifecycle), and section 5.3's trust tiers - derived
from the actor strings, never stored. Section 7 fixes the actor convention
(`human:<id>`, `process:<id>`, `<producer>/<version>`) that makes
"confirmed by a person" a machine-checkable distinction.
