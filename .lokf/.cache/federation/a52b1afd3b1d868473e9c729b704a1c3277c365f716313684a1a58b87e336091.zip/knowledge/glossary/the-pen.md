---
type: GlossaryTerm
id: https://w3id.org/ktl/knowledge/glossary/the-pen
title: The pen
description: "The name for `knowledge-apply.sh`, the only way ktl-librarian writes the bundle: it applies the operations in `.lokf/patch.yaml`, stamps `generated`, keeps the index in step, and refuses a `human:` actor."
definition: The name the docs give `knowledge-apply.sh`, the script through which ktl-librarian writes every change to the bundle. The librarian describes each change as an operation in `.lokf/patch.yaml`, and the pen checks every operation and writes the files, or writes nothing.
genre: reference
resource: skills/ktl-sidecar/templates/scripts/knowledge-apply.sh
sources:
- resource: docs/architecture.md
- resource: docs/for-the-curious.md
- resource: skills/ktl-librarian/references/patch.md
about:
- https://w3id.org/ktl/knowledge/glossary/knowledge-bundle
relatedTo:
- https://w3id.org/ktl/knowledge/playbooks/ktl-librarian-skill
- https://w3id.org/ktl/knowledge/explanation/why-a-registrar-role
generated:
  by: process:ktl-librarian
  at: "2026-10-13T15:08:54Z"
status: draft
verified:
- by: process:ktl-librarian
  at: "2026-10-15T01:30:10Z"
---

# Overview

*The pen* is the name the docs give `knowledge-apply.sh`. ktl-librarian never edits a file under `.lokf/knowledge/` by hand. It describes each change as an operation in `.lokf/patch.yaml`, and the pen checks every operation and writes the files, or refuses the whole file and writes nothing.

The pen:

- stamps `generated` from the clock;
- keeps a concept's `description` equal to its two index bullets;
- files each line in `log.md`;
- moves a feedback entry the librarian handled into `.lokf/questions.md`, ten to a patch at most.

It refuses a `human:` actor, a rewrite of text a person wrote, and the deletion of a concept a person confirmed or left a note on. It also refuses a patch after which any concept it writes would hold a person's record other than the one the file held. That covers a `human:` event or a person's note added, changed or removed, however the operations spelt it.

In the scheduled run, the wrapper applies the patch file after the agent has finished, and refuses a run in which the agent changed any other file. A patch may also carry `handoff`, up to ten lines for the person reviewing the change, in the librarian's own words. The pen holds each to one line of printable text and writes none of it to the bundle. The scheduled pull request shows them under *From the librarian*.

The pen is the librarian's only way to write the bundle, and the bundle has other writers: a person writes the curator's verdicts through ktl-curator or the KTL Curator plugin. The architecture page names the pen as the registrar for the librarian.
