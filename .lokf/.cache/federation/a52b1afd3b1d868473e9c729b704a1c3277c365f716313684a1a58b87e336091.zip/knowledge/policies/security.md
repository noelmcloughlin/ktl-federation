---
type: Policy
id: https://w3id.org/ktl/knowledge/policies/security
title: Security policy
description: How to report a vulnerability privately, supported versions, and a surface table (what executes here, what guards it) that links to the shared threat model instead of restating it.
genre: reference
resource: SECURITY.md
sources:
- resource: SECURITY.md
- resource: scripts/validate-repository.sh
- resource: CHANGELOG.md
generated:
  by: human:noelmcloughlin
  at: "2026-10-13T00:41:54Z"
references:
- https://w3id.org/ktl/knowledge/policies/threat-model
- https://w3id.org/ktl/knowledge/playbooks/repository-validation
verified:
- by: human:noelmcloughlin
  at: "2026-09-10T00:00:00Z"
- by: human:noelmcloughlin
  at: "2026-09-26T20:21:41Z"
- by: process:ktl-librarian
  at: "2026-10-13T15:08:54Z"
- by: human:noelmcloughlin
  at: "2026-10-13T00:41:54Z"
stale_after: 2027-03-26
status: draft
---

# Overview

`SECURITY.md` is a policy, not a threat model. It says how to report, what executes here, and what guards each surface, in a line or two that links to where the reasoning lives: a workflow header, a skill's own guardrail, or [the shared threat model](threat-model.md). It took that shape in 0.17.1 (2026-09-14, `CHANGELOG.md`), when the design moved to `docs/threat-model.md`.

# Reporting a vulnerability

Report through GitHub's private vulnerability reporting, not a public issue or a pull request. Say which file is affected and why it is exploitable. For a template that gets copied into other repositories, say whether the issue is in the template itself or appears only after a consumer customizes it. One person maintains the repository, so expect a first reply in days, not hours, and no bounty.

# Supported versions

Only the latest published tag receives fixes. A security fix is published as a patch release and is noted in `CHANGELOG.md`.

A fix to a template reaches a repository that already has a sidecar only when ktl-sidecar copies the templates there again. Updating the skill, or moving `TRUST_LADDER_SKILLS_REF`, does not touch them. `knowledge-preflight.sh` reports the drift on its `copies` line, and ktl-sidecar's repair re-copies the files.

An automated skill audit, such as Snyk's or Socket's on a skills catalog, gets its answer in the file each finding names and in the threat model's prompt-injection section. A finding that looks unanswered is reported the same way as any other.

# What executes here

The repository is mostly Markdown. Four things in it run, or are run by other systems, and they are the attack surface:

| Surface | What guards it |
| --- | --- |
| the seven scripts and three workflows under `skills/ktl-sidecar/templates/`, which the sidecar copies into other repositories, where they run | the template's own design: separate jobs, so the agent never meets a write token; a `publish` job that confines the patch to the bundle and refuses a `human:` claim; a preflight and a forge-free gate that only read git and gpg |
| this repository's workflows: `validate.yml` on every pull request; `knowledge-registrar.yaml`, `knowledge-librarian.yaml` and `knowledge-release.yaml`, its own copies of the templates; `semantic-release.yml` and `publish.yml`, which write to `main` behind the `release` Environment | actions pinned to commit SHAs, `permissions: {}` at the top of every workflow, and harden-runner in audit mode; each workflow's header comment says why it is shaped as it is |
| `skills/ktl-prose/scripts/prose-check.py` and `skills/ktl-docent/scripts/`, the scripts a skill runs in place, in whichever repository installs it | `prose-check.py` uses the standard library only; it reads the files it is given and the skill's own word list, calls `git show` with an argument list and writes nothing. The docent's two are byte-identical copies of the sidecar's templates: `knowledge-report.sh` reads the bundle and git, and `knowledge-feedback.sh` writes one line to `.lokf/feedback.md`. None opens a network connection |
| the five skills' `SKILL.md` and `references/` prose, executed by whichever LLM agent runs it, here and in every consumer | each skill's guardrail for its own input path: content the agent did not author is quoted, never followed, and only an authenticated person's verdict is recorded as one |

A skill's `Scope:` line is prose, not a permission. Run interactively, an agent has whatever access the harness grants it, and only the scheduled workflow enforces its scope. So review what the agent changed before you commit. Four skills, ktl-curator, ktl-librarian, ktl-prose and ktl-sidecar, also run the scripts in the repository's `.lokf/scripts/`, which anyone who can commit there can change. ktl-docent runs only its own scripts, so a question runs none of the repository's code.

# Not covered

- A compromised runner, upstream action or agent harness: the policy is a baseline, not a sandbox. A finding there is still reported, with scope and reproduction.
- Whether a bundle is *true*. The gate proves who vouched, not what they read, and `AI_COVENANT.md` sets the human-accountability rules.
- A reader's own words to ktl-docent. That boundary belongs to the agent harness, not to a Markdown file.

Check 10 of `scripts/validate-repository.sh` fails when `SECURITY.md` outgrows a word budget of 900. Its comment says the file sits between 450 and 800 words and ran to 1,400 to 1,900 before `docs/threat-model.md` took the design.

## Open questions

- 2026-10-14, process:ktl-librarian: Since 2026-10-14 `SECURITY.md` lists ktl-website's templates and its preflight as a surface of their own. It names `knowledge-website.yaml` among this repository's copies of the templates, counts the six skills' prose, and names five skills that run `.lokf/scripts/`, ktl-website among them. This concept carries the earlier table and four skills. `SECURITY.md` itself still says four surfaces above a table of five rows.
- 2026-10-15, process:ktl-librarian: Since 0.41.0 the ktl-website row of `SECURITY.md` says the build job also runs `just` when the site builds a folder through a recipe, and that the sync runs the commands `site.config.mjs` names to build the schema's pages and the data. Since 2026-10-14 `SECURITY.md` also counts five surfaces, matching its table. This concept carries neither.
