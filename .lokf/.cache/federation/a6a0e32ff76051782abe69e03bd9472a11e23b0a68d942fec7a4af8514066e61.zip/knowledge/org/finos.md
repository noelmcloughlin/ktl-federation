---
type: Organization
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/org/finos
title: FINOS
description: The Fintech Open Source Foundation - publisher of the AI Governance Framework and the curated framework datasets this repository ships as BYOD files.
resource: https://w3id.org/finos
timestamp: "2026-08-12T00:00:00Z"
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# FINOS

FINOS (Fintech Open Source Foundation) fosters open collaboration in financial services technology. It publishes the [AI Governance Framework](../references/finos-aigf.md), whose repository also curates the framework encodings (EU AI Act, ISO/IEC 42001, NIST profiles, OWASP top-10s, SR 11-7, FFIEC) that `linkml/scripts/build_finos_data.py` turns into this repository's `byo/data/*.yaml` files.
