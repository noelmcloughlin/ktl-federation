---
type: Organization
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/org/ibm
title: IBM
description: Publisher of the ai-atlas-nexus project and its AI Risk Ontology, the LinkML schema and upstream dataset AI-LinkMO builds on.
resource: https://ibm.github.io/ai-atlas-nexus/
timestamp: "2026-08-12T00:00:00Z"
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# IBM

IBM publishes [ai-atlas-nexus](https://ibm.github.io/ai-atlas-nexus/), the Python package (a `pyproject.toml` dependency of this repository) that provides the [AI Risk Ontology](../references/ai-risk-ontology.md) LinkML schema and the upstream risk/taxonomy data served by every AI-LinkMO access pattern.
