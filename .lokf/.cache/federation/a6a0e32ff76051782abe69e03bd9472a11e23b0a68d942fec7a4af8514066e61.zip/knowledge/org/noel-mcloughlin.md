---
type: Person
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/org/noel-mcloughlin
title: Noel McLoughlin
description: Author and maintainer of AI-LinkMO.
resource: https://github.com/noelmcloughlin
timestamp: "2026-08-12T00:00:00Z"
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# Noel McLoughlin

Author and maintainer of AI-LinkMO. GitHub: <https://github.com/noelmcloughlin>.
