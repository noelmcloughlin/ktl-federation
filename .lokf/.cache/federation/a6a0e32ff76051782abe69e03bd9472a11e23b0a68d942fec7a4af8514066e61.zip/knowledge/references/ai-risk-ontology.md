---
type: Reference
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/ai-risk-ontology
title: AI Risk Ontology (ai-atlas-nexus)
description: IBM's AI Risk Ontology from the ai-atlas-nexus project - the LinkML schema (System view and Risk view) that all AI-LinkMO data, endpoints and CLI parameters align to.
resource: https://ibm.github.io/ai-atlas-nexus/ontology/
timestamp: "2026-08-12T00:00:00Z"
source:
  - https://noelmcloughlin.github.io/ai-linkmo/knowledge/org/ibm
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# AI Risk Ontology (ai-atlas-nexus)

External authority encoded by this repository's data. Canonical source: <https://ibm.github.io/ai-atlas-nexus/ontology/>.
