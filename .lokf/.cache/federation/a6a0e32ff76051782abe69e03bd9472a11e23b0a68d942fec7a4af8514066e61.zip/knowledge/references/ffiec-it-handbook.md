---
type: Reference
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/ffiec-it-handbook
title: FFIEC IT Examination Handbook
description: The Federal Financial Institutions Examination Council's Information Technology Examination Handbook.
resource: https://ithandbook.ffiec.gov/
timestamp: "2026-08-12T00:00:00Z"
verified:
  - by: process:ktl-librarian
    at: "2026-09-12T00:00:00Z"
---

# FFIEC IT Examination Handbook

External authority encoded by this repository's data. Canonical source: <https://ithandbook.ffiec.gov/>.
