---
type: Reference
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/finos-aigf
title: FINOS AI Governance Framework
description: "The FINOS AI Governance Framework: risk register, mitigation catalogue and use-case library for AI in financial services."
resource: https://air-governance-framework.finos.org/
timestamp: "2026-08-12T00:00:00Z"
source:
  - https://noelmcloughlin.github.io/ai-linkmo/knowledge/org/finos
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# FINOS AI Governance Framework

External authority encoded by this repository's data. Canonical source: <https://air-governance-framework.finos.org/>.
