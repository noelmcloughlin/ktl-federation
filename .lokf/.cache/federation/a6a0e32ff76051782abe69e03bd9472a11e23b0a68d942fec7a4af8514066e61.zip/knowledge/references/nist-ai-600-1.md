---
type: Reference
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/nist-ai-600-1
title: NIST AI 600-1 (Generative AI Profile)
description: NIST AI 600-1, the Generative Artificial Intelligence Profile companion to the NIST AI Risk Management Framework.
resource: https://doi.org/10.6028/NIST.AI.600-1
timestamp: "2026-08-12T00:00:00Z"
relatedTo:
  - https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/nist-ai-rmf
verified:
  - by: process:ktl-librarian
    at: "2026-09-25T20:33:34Z"
---

# NIST AI 600-1 (Generative AI Profile)

External authority encoded by this repository's data. Canonical source: <https://doi.org/10.6028/NIST.AI.600-1>.
