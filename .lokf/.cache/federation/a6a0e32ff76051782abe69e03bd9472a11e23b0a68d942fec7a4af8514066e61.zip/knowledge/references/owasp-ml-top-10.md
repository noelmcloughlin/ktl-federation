---
type: Reference
genre: reference
id: https://noelmcloughlin.github.io/ai-linkmo/knowledge/references/owasp-ml-top-10
title: OWASP ML Security Top 10
description: The OWASP Machine Learning Security Top 10 risks.
resource: https://owasp.org/www-project-machine-learning-security-top-10/
timestamp: "2026-08-12T00:00:00Z"
verified:
  - by: process:ktl-librarian
    at: "2026-09-12T00:00:00Z"
---

# OWASP ML Security Top 10

External authority encoded by this repository's data. Canonical source: <https://owasp.org/www-project-machine-learning-security-top-10/>.
